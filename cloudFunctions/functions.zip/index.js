const functions = require("firebase-functions");
const admin = require('firebase-admin');
const ufs = require("url-file-size");

admin.initializeApp();
// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
// exports.helloWorld = functions.https.onRequest((request, response) => {
//   functions.logger.info("Hello logs!", {structuredData: true});
//   response.send("Hello from Firebase!");
// });

const stripe = require('stripe')('sk_test_51LuZxNGg5YK1Q5KruLphGFBgi7HYCPOz4fC1Dr1wY1kAri07YHuUDVICvoestFq8uE6Kzrnjr7JyqAvjVisbwH6s000OsuQMEY');

exports.createSubscription = functions.https.onCall((data, context) => {
    return stripe.subscriptions.create({
        customer: data.stripeCustomerId,
        items: [{ price: data.price }],
        metadata: { uid: data.uid },
		payment_behavior: 'default_incomplete',
		payment_settings: { save_default_payment_method: 'on_subscription' },
		expand: ['latest_invoice.payment_intent'],
    });
});

exports.stripeCreateCustomer = functions.https.onCall((data, context) => {
    return stripe.customers.create({
        email: data.email,
        name: data.displayName,
        metadata: { uid: data.uid },
    });
});

exports.paymentSubscriptionIntent = functions.https.onCall(async() => {
	return await stripe.paymentIntents.create({
	  payment_method_types: ['card'],
	  amount: 1099,
	  currency: 'usd',
	});
})
exports.deleteUser = functions.https.onCall((data, context) => {     
    return admin.auth().deleteUser(data.uid)      
});

exports.getFileSize = functions.https.onCall((data, context) => {
	return ufs(data.fileUrl)    
});